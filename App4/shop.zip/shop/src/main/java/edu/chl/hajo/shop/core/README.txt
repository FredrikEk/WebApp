*** The shop model ***

This is an basic OO model of a (generic web) shop

Application specific parts in core-package reusable parts
in util-package.

No defensive programming (validation) here, handled later.

No concurrency, handled later

No sorting of results, handled by database later
