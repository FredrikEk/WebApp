'use strict';

/* Filters */

angular.module('PersonRegFilters', []).filter('startFrom', function() {
    return function(input, start) {
        // Not used but or use if you like (have to implement)
    };
});

