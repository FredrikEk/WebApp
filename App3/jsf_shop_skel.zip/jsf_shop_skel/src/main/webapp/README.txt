    
*** README ***

This JSF workshop uses CDI **only** (no JSF Managed Beans), Bean validation
and runs on GlassFish 


Injection
--------
Always prefer setter (testing possible)

Realms
-------
Create a user in the (default) file realm in GlassFish

Starts GlassFish Admin console (Servers > GlassFish, right click > 
View Domain Admin Console)

Goto: server-config > Security > Realms > File > manage users 
> New ...
