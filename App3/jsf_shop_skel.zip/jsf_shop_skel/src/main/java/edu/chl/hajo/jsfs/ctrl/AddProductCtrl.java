package edu.chl.hajo.jsfs.ctrl;

/**
 *
 * @author hajo
 */

public class AddProductCtrl {

  
}
