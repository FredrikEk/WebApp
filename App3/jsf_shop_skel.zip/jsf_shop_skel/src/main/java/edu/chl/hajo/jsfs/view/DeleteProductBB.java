package edu.chl.hajo.jsfs.view;

/**
 *
 * @author hajo
 */

public class DeleteProductBB  {

 
}
